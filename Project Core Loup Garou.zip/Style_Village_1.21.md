# Project Core — Village corrigé (Java 1.21.0)

Les nouvelles clés sont orientées avec leur poignée au point de prise des outils Minecraft, pour les mains droite et gauche, en première et troisième personne. La position exacte reste à vérifier en jeu.

Le style Village est appliqué directement aux textures vanilla de l’inventaire personnel (touche E, mode survie) et des coffres/menus de type coffre de 1 à 6 rangées. Aucun titre spécial et aucune modification de Skript ne sont nécessaires pour ces fonds. Cela s’applique à tous ces coffres et menus, quel que soit le monde. L’inventaire créatif, les fours et les autres conteneurs gardent leur propre interface.

Les anciens modèles et textures de clés/ingrédients ont été retirés. Les six ingrédients gardent leurs objets et identifiants 100001 à 100006 ; leurs modèles pointent directement vers les nouvelles textures.

Les fonds par caractères spéciaux de la précédente version ont été remplacés par les textures de conteneur natives. Si vous aviez ajouté les glyphes U+F801/U+F802 et U+E101 à U+E106 dans vos scripts, retirez-les des titres.

Rune des pouvoirs :
```mcfunction
/give @s minecraft:echo_shard[custom_model_data=23001,custom_name='{"text":"Pouvoirs","color":"green","italic":false}'] 1
```
Livre :
```mcfunction
/give @s minecraft:book[custom_model_data=23002,custom_name='{"text":"Grimoire du village","color":"gold","italic":false}'] 1
```
Le pack ne remplace pas l’objet Nether Star donné par vos scripts ; la rune ci-dessus reste l’éclat d’écho personnalisé à utiliser dans le menu. Les livres écrits existants prennent la couverture en ajoutant CustomModelData 23002, sans toucher à leurs pages.

Test local : activer ce ZIP en tête des packs puis F3+T. Si le serveur distribue une ancienne version du pack, désactiver temporairement son pack dans les paramètres de l’adresse serveur pour tester le nouveau ZIP local.

ZIP, JSON, références de modèles et géométrie des cases vérifiés. Rendu non testé sur le serveur. Les textures et sons précédemment publiés sont conservés ; le kit séparé de sorts non publié n’est pas ajouté.
