# Clés et dague — Java 1.21.0

Les 13 modèles de boutons remplacés par une clé sont supprimés : boutons vanilla restaurés. Les clés utilisent maintenant une pépite de fer avec CustomModelData 23003. Les scripts qui donnent les anciennes clés-boutons doivent être adaptés séparément.

/give @s minecraft:iron_nugget[custom_model_data=23003,custom_name='{"text":"Clé","italic":false}'] 1
/give @s minecraft:iron_sword[custom_model_data=23004,custom_name='{"text":"Dague du voleur","italic":false}'] 1

Les objets ordinaires conservent leur apparence. La dague conserve les caractéristiques et les dégâts de l'épée en fer ; aucun pouvoir ni rôle n'est ajouté par le pack. La prise de la clé existante est conservée.
